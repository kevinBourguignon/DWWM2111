<h3 class="oceanwp-tp-block-description alert">
	<?php printf( esc_html__( 'To complete the functionality of this section, please update %1$s plugin to its latest version.', 'oceanwp' ), $panel_args['plugin_name'] ); ?>
</h3>
